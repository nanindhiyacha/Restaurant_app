package com.example.aplikasi_restaurant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
