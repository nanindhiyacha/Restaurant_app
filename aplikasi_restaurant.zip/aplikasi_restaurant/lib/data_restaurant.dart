import 'dart:convert';

class DaftarRestaurant {
  final Restaurant restaurants;

  DaftarRestaurant({required this.restaurants});

  factory DaftarRestaurant.fromJson(Map<String, dynamic> json){
    return DaftarRestaurant(restaurants: Restaurant.fromJson(json['restaurants']));
  }

  Map<String, dynamic> toJson() => {
    'restaurant': restaurants.toJson(),
  };
}

class Restaurant {
  final String id;
  final String name;
  final String description;
  final String pictureId;
  final String city;
  final double rating;
  final Menu menus;

  Restaurant({
    required this.id,
    required this.name,
    required this.description,
    required this.pictureId,
    required this.city,
    required this.rating,
    required this.menus
  });

  factory Restaurant.fromJson(Map<String, dynamic> json){
    return Restaurant(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      pictureId: json['pictureId'],
      city: json['city'],
      rating: json['rating'],
      menus: Menu.fromJson(json['menus'])
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'description': description,
    'pictureId': pictureId,
    'city': city,
    'rating': rating,
    'menus': menus.toJson(),
  };
}

class Menu {
  final Food foods;
  final Food drinks;

  Menu({
    required this.foods,
    required this.drinks
  });

  factory Menu.fromJson(Map<String, dynamic> json){
    return Menu(
      foods: Food.fromJson(json['foods']),
      drinks: Food.fromJson(json['drinks'])
    );
  }

  Map<String, dynamic> toJson() => {
    'foods': foods,
    'drinks': drinks,
  };
}

class Food {
  final String name;

  Food({
    required this.name
  });

  factory Food.fromJson(Map<String, dynamic> json){
    return Food(name: json['name']);
  }

  Map<String, dynamic> toJson() => {
    'name': name,
  };
}

List<DaftarRestaurant> parseDaftarRestaurant(String? json) {
  if (json == null) {
    return [];
  }
  final List parsed = jsonDecode(json);
  return parsed.map((json) => DaftarRestaurant.fromJson(json)).toList();
}