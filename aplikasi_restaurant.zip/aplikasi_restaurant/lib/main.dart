import 'package:aplikasi_restaurant/data_restaurant.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'News App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: NewsListPage.routeName,
      routes: {
        NewsListPage.routeName: (context) => NewsListPage(),
      },
    );
  }
}

class NewsListPage extends StatelessWidget {
  static const routeName = '/data_restaurant_list';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Restaurant App'),
      ),
      body: FutureBuilder<String>(
        future:
        DefaultAssetBundle.of(context).loadString('assets/local_restaurant.json'),
        builder: (context, snapshot) {
          final List<DaftarRestaurant> daftarRestaurant = parseDaftarRestaurant(snapshot.data);
          return ListView.builder(
            itemCount: daftarRestaurant.length,
            itemBuilder: (context, index) {
              return _buildArticleItem(context, daftarRestaurant[index]);
            },
          );
        },
      ),
    );
  }

  Widget _buildArticleItem(BuildContext context, DaftarRestaurant daftarRestaurant) {
    return ListTile(
      contentPadding:
      const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      leading: Image.network(
        daftarRestaurant.restaurants.pictureId,
        width: 100,
      ),
      title: Text(daftarRestaurant.restaurants.name),
      subtitle: Text(daftarRestaurant.restaurants.city),
    );
  }
}